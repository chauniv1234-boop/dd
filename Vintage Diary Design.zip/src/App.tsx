import { useState, useEffect } from "react";
import { DiaryHeader } from "./components/DiaryHeader";
import { DiaryEditor } from "./components/DiaryEditor";
import { DiaryList } from "./components/DiaryList";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { Toaster } from "./components/ui/sonner";
import { toast } from "sonner@2.0.3";

interface DiaryEntryData {
  id: string;
  date: string;
  title: string;
  content: string;
  tags: string[];
  isFavorite: boolean;
}

export default function App() {
  const [entries, setEntries] = useState<DiaryEntryData[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [editingEntry, setEditingEntry] = useState<DiaryEntryData | null>(null);

  // Load entries from localStorage on mount
  useEffect(() => {
    const savedEntries = localStorage.getItem("diaryEntries");
    if (savedEntries) {
      setEntries(JSON.parse(savedEntries));
    }
  }, []);

  // Save entries to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("diaryEntries", JSON.stringify(entries));
  }, [entries]);

  const handleSave = (date: Date, content: string, title: string, tags: string[], isFavorite: boolean) => {
    const dateStr = date.toISOString().split("T")[0];
    
    if (editingEntry) {
      // Update existing entry
      setEntries(entries.map(entry => 
        entry.id === editingEntry.id 
          ? { ...entry, title, content, date: dateStr, tags, isFavorite }
          : entry
      ));
      setEditingEntry(null);
      toast.success("일기가 수정되었습니다");
    } else {
      // Create new entry
      const existingEntryIndex = entries.findIndex(e => e.date === dateStr);
      
      if (existingEntryIndex !== -1) {
        // Update existing entry for the same date
        const updated = [...entries];
        updated[existingEntryIndex] = {
          ...updated[existingEntryIndex],
          title,
          content,
          tags,
          isFavorite
        };
        setEntries(updated);
        toast.success("일기가 수정되었습니다");
      } else {
        // Add new entry
        const newEntry: DiaryEntryData = {
          id: Date.now().toString(),
          date: dateStr,
          title,
          content,
          tags,
          isFavorite
        };
        setEntries([newEntry, ...entries]);
        toast.success("일기가 저장되었습니다");
      }
    }
  };

  const handleDelete = (id: string) => {
    setEntries(entries.filter(entry => entry.id !== id));
    if (editingEntry?.id === id) {
      setEditingEntry(null);
    }
    toast.success("일기가 삭제되었습니다");
  };

  const handleToggleFavorite = (id: string) => {
    setEntries(entries.map(entry =>
      entry.id === id
        ? { ...entry, isFavorite: !entry.isFavorite }
        : entry
    ));
  };

  const handleEntryClick = (entry: DiaryEntryData) => {
    setEditingEntry(entry);
    setSelectedDate(new Date(entry.date));
  };

  const getCurrentEntry = () => {
    const dateStr = selectedDate.toISOString().split("T")[0];
    return entries.find(e => e.date === dateStr);
  };

  const sortedEntries = [...entries].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <div 
      className="min-h-screen py-8 px-4"
      style={{ backgroundColor: '#F5F5F0' }}
    >
      <div className="max-w-6xl mx-auto">
        <DiaryHeader />

        <Tabs defaultValue="write" className="w-full">
          <TabsList 
            className="grid w-full max-w-md mx-auto mb-8"
            style={{ backgroundColor: '#E6D8C3' }}
          >
            <TabsTrigger 
              value="write"
              style={{ color: '#5D866C' }}
              className="data-[state=active]:bg-[#5D866C] data-[state=active]:text-white"
            >
              일기 쓰기
            </TabsTrigger>
            <TabsTrigger 
              value="list"
              style={{ color: '#5D866C' }}
              className="data-[state=active]:bg-[#5D866C] data-[state=active]:text-white"
            >
              일기 목록
            </TabsTrigger>
          </TabsList>

          <TabsContent value="write">
            <div className="max-w-3xl mx-auto">
              <DiaryEditor
                onSave={handleSave}
                selectedDate={selectedDate}
                onDateChange={(date) => {
                  if (date) {
                    setSelectedDate(date);
                    setEditingEntry(null);
                  }
                }}
                existingEntry={editingEntry || getCurrentEntry()}
              />
            </div>
          </TabsContent>

          <TabsContent value="list">
            <div className="max-w-6xl mx-auto">
              <DiaryList
                entries={sortedEntries}
                onEntryClick={handleEntryClick}
                onDelete={handleDelete}
                onToggleFavorite={handleToggleFavorite}
              />
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Toaster />
    </div>
  );
}
