import { useState, useEffect } from "react";
import { Calendar } from "./ui/calendar";
import { Textarea } from "./ui/textarea";
import { Button } from "./ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { CalendarIcon, Save, Star, X, Tag } from "lucide-react";
import { format } from "date-fns";
import { ko } from "date-fns/locale";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";

interface DiaryEditorProps {
  onSave: (date: Date, content: string, title: string, tags: string[], isFavorite: boolean) => void;
  selectedDate: Date;
  onDateChange: (date: Date | undefined) => void;
  existingEntry?: { title: string; content: string; tags?: string[]; isFavorite?: boolean };
}

export function DiaryEditor({ onSave, selectedDate, onDateChange, existingEntry }: DiaryEditorProps) {
  const [title, setTitle] = useState(existingEntry?.title || "");
  const [content, setContent] = useState(existingEntry?.content || "");
  const [tags, setTags] = useState<string[]>(existingEntry?.tags || []);
  const [tagInput, setTagInput] = useState("");
  const [isFavorite, setIsFavorite] = useState(existingEntry?.isFavorite || false);

  useEffect(() => {
    setTitle(existingEntry?.title || "");
    setContent(existingEntry?.content || "");
    setTags(existingEntry?.tags || []);
    setIsFavorite(existingEntry?.isFavorite || false);
  }, [existingEntry]);

  const handleSave = () => {
    if (content.trim()) {
      onSave(selectedDate, content, title, tags, isFavorite);
      if (!existingEntry) {
        setTitle("");
        setContent("");
        setTags([]);
        setIsFavorite(false);
      }
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleTagInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddTag();
    }
  };

  return (
    <div 
      className="p-6 rounded-lg shadow-lg"
      style={{ 
        backgroundColor: '#E6D8C3',
        borderLeft: '4px solid #C2A68C'
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className="justify-start border-[#C2A68C] hover:bg-[#F5F5F0]"
              style={{ color: '#5D866C' }}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {format(selectedDate, "PPP", { locale: ko })}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={onDateChange}
              initialFocus
            />
          </PopoverContent>
        </Popover>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsFavorite(!isFavorite)}
          className={isFavorite ? "text-yellow-500" : ""}
        >
          <Star 
            className="w-5 h-5" 
            fill={isFavorite ? "currentColor" : "none"}
          />
        </Button>
      </div>

      <input
        type="text"
        placeholder="제목을 입력하세요"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="w-full p-3 mb-3 rounded border-none outline-none"
        style={{ 
          backgroundColor: '#F5F5F0',
          color: '#5D866C',
          fontFamily: 'Georgia, serif'
        }}
      />

      <div className="mb-3">
        <div className="flex gap-2 mb-2">
          <div className="relative flex-1">
            <Tag 
              className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4" 
              style={{ color: '#5D866C' }}
            />
            <Input
              placeholder="태그 추가 (Enter로 입력)"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={handleTagInputKeyDown}
              className="pl-10 border-none"
              style={{ 
                backgroundColor: '#F5F5F0',
                color: '#5D866C'
              }}
            />
          </div>
          <Button
            onClick={handleAddTag}
            variant="outline"
            size="sm"
            className="border-[#5D866C]"
            style={{ color: '#5D866C' }}
          >
            추가
          </Button>
        </div>
        
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <Badge 
                key={tag}
                variant="secondary"
                className="gap-1"
                style={{ backgroundColor: '#5D866C', color: 'white' }}
              >
                {tag}
                <X 
                  className="w-3 h-3 cursor-pointer hover:opacity-70" 
                  onClick={() => handleRemoveTag(tag)}
                />
              </Badge>
            ))}
          </div>
        )}
      </div>

      <Textarea
        placeholder="오늘 하루는 어떠셨나요? 당신의 이야기를 들려주세요..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        className="min-h-[200px] resize-none border-none outline-none"
        style={{ 
          backgroundColor: '#F5F5F0',
          color: '#5D866C',
          fontFamily: 'Georgia, serif',
          lineHeight: '1.8'
        }}
      />

      <div className="flex justify-end mt-4">
        <Button
          onClick={handleSave}
          className="gap-2"
          style={{ backgroundColor: '#5D866C' }}
        >
          <Save className="w-4 h-4" />
          저장하기
        </Button>
      </div>
    </div>
  );
}
