import { format } from "date-fns";
import { ko } from "date-fns/locale";
import { Star, Trash2 } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface DiaryEntryProps {
  date: Date;
  title: string;
  content: string;
  tags?: string[];
  isFavorite?: boolean;
  onClick: () => void;
  onDelete: () => void;
  onToggleFavorite: () => void;
}

export function DiaryEntry({ 
  date, 
  title, 
  content, 
  tags = [], 
  isFavorite = false, 
  onClick, 
  onDelete,
  onToggleFavorite 
}: DiaryEntryProps) {
  return (
    <div
      className="group relative rounded-lg shadow-md cursor-pointer transition-all hover:shadow-xl overflow-hidden"
      style={{
        backgroundColor: '#E6D8C3',
        aspectRatio: '2/3',
        minHeight: '320px'
      }}
      onClick={onClick}
    >
      {/* Book Cover Style Background */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: 'linear-gradient(45deg, #5D866C 25%, transparent 25%, transparent 75%, #5D866C 75%, #5D866C), linear-gradient(45deg, #5D866C 25%, transparent 25%, transparent 75%, #5D866C 75%, #5D866C)',
          backgroundSize: '20px 20px',
          backgroundPosition: '0 0, 10px 10px'
        }}
      />

      {/* Content */}
      <div className="relative h-full flex flex-col p-5">
        {/* Header with date and actions */}
        <div className="flex items-start justify-between mb-3">
          <div className="text-xs" style={{ color: '#5D866C' }}>
            {format(date, "yyyy.MM.dd", { locale: ko })}
          </div>
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite();
              }}
              className="h-7 w-7 p-0"
            >
              <Star 
                className="w-4 h-4" 
                style={{ color: isFavorite ? '#FFD700' : '#5D866C' }}
                fill={isFavorite ? '#FFD700' : 'none'}
              />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              className="h-7 w-7 p-0 hover:bg-red-100"
            >
              <Trash2 className="w-4 h-4" style={{ color: '#5D866C' }} />
            </Button>
          </div>
        </div>

        {/* Favorite indicator */}
        {isFavorite && (
          <div className="absolute top-3 right-3 opacity-100">
            <Star 
              className="w-5 h-5" 
              style={{ color: '#FFD700' }}
              fill="#FFD700"
            />
          </div>
        )}

        {/* Title */}
        <h3 
          className="mb-3 line-clamp-2 min-h-[3em]" 
          style={{ 
            color: '#5D866C', 
            fontFamily: 'Georgia, serif'
          }}
        >
          {title || "제목 없음"}
        </h3>

        {/* Content preview */}
        <p
          className="flex-1 line-clamp-6 text-sm mb-3"
          style={{ 
            color: '#5D866C',
            fontFamily: 'Georgia, serif',
            lineHeight: '1.6',
            opacity: 0.8
          }}
        >
          {content}
        </p>

        {/* Tags */}
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-auto">
            {tags.slice(0, 3).map((tag) => (
              <Badge 
                key={tag}
                variant="outline"
                className="text-xs"
                style={{ 
                  borderColor: '#5D866C',
                  color: '#5D866C',
                  backgroundColor: 'rgba(93, 134, 108, 0.1)'
                }}
              >
                {tag}
              </Badge>
            ))}
            {tags.length > 3 && (
              <Badge 
                variant="outline"
                className="text-xs"
                style={{ 
                  borderColor: '#5D866C',
                  color: '#5D866C',
                  backgroundColor: 'rgba(93, 134, 108, 0.1)'
                }}
              >
                +{tags.length - 3}
              </Badge>
            )}
          </div>
        )}

        {/* Decorative border */}
        <div 
          className="absolute top-0 left-0 w-full h-1"
          style={{ backgroundColor: '#5D866C' }}
        />
      </div>
    </div>
  );
}
