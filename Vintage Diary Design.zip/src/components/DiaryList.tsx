import { useState, useMemo } from "react";
import { format } from "date-fns";
import { ko } from "date-fns/locale";
import { DiaryEntry } from "./DiaryEntry";
import { Input } from "./ui/input";
import { Search, Calendar, Star, X } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Calendar as CalendarComponent } from "./ui/calendar";

interface DiaryEntryData {
  id: string;
  date: string;
  title: string;
  content: string;
  tags: string[];
  isFavorite: boolean;
}

interface DiaryListProps {
  entries: DiaryEntryData[];
  onEntryClick: (entry: DiaryEntryData) => void;
  onDelete: (id: string) => void;
  onToggleFavorite: (id: string) => void;
}

export function DiaryList({ entries, onEntryClick, onDelete, onToggleFavorite }: DiaryListProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [showFavoriteOnly, setShowFavoriteOnly] = useState(false);
  const [dateRange, setDateRange] = useState<{ from: Date | undefined; to: Date | undefined }>({
    from: undefined,
    to: undefined
  });

  // Get all unique tags
  const allTags = useMemo(() => {
    const tagSet = new Set<string>();
    entries.forEach(entry => {
      entry.tags?.forEach(tag => tagSet.add(tag));
    });
    return Array.from(tagSet).sort();
  }, [entries]);

  // Filter entries
  const filteredEntries = useMemo(() => {
    let filtered = entries;

    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(entry => 
        entry.title.toLowerCase().includes(query) ||
        entry.content.toLowerCase().includes(query) ||
        format(new Date(entry.date), "yyyy년 M월 d일", { locale: ko }).includes(query)
      );
    }

    // Tag filter
    if (selectedTags.length > 0) {
      filtered = filtered.filter(entry =>
        selectedTags.some(tag => entry.tags?.includes(tag))
      );
    }

    // Favorite filter
    if (showFavoriteOnly) {
      filtered = filtered.filter(entry => entry.isFavorite);
    }

    // Date range filter
    if (dateRange.from) {
      filtered = filtered.filter(entry => {
        const entryDate = new Date(entry.date);
        const from = new Date(dateRange.from!);
        from.setHours(0, 0, 0, 0);
        
        if (dateRange.to) {
          const to = new Date(dateRange.to);
          to.setHours(23, 59, 59, 999);
          return entryDate >= from && entryDate <= to;
        }
        
        return entryDate >= from;
      });
    }

    return filtered;
  }, [entries, searchQuery, selectedTags, showFavoriteOnly, dateRange]);

  const toggleTag = (tag: string) => {
    setSelectedTags(prev =>
      prev.includes(tag)
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedTags([]);
    setShowFavoriteOnly(false);
    setDateRange({ from: undefined, to: undefined });
  };

  const hasActiveFilters = searchQuery || selectedTags.length > 0 || showFavoriteOnly || dateRange.from;

  if (entries.length === 0) {
    return (
      <div 
        className="text-center py-16 rounded-lg"
        style={{ 
          backgroundColor: '#E6D8C3',
          color: '#C2A68C'
        }}
      >
        <Calendar className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p>아직 작성한 일기가 없습니다.</p>
        <p className="text-sm mt-2">첫 번째 일기를 작성해보세요!</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filter Bar */}
      <div 
        className="p-4 rounded-lg space-y-4"
        style={{ backgroundColor: '#E6D8C3' }}
      >
        {/* Stats */}
        <div className="flex flex-wrap items-center gap-3">
          <Badge 
            variant="secondary" 
            className="px-4 py-2"
            style={{ 
              backgroundColor: '#5D866C',
              color: 'white'
            }}
          >
            전체 {entries.length}개
          </Badge>
          {filteredEntries.length !== entries.length && (
            <Badge 
              variant="outline" 
              className="px-4 py-2"
              style={{ 
                borderColor: '#5D866C',
                color: '#5D866C'
              }}
            >
              검색 결과 {filteredEntries.length}개
            </Badge>
          )}
          <Badge 
            variant="outline" 
            className="px-4 py-2"
            style={{ 
              borderColor: '#FFD700',
              color: '#5D866C'
            }}
          >
            <Star className="w-3 h-3 mr-1" fill="#FFD700" style={{ color: '#FFD700' }} />
            즐겨찾기 {entries.filter(e => e.isFavorite).length}개
          </Badge>
        </div>

        {/* Search */}
        <div className="relative">
          <Search 
            className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4" 
            style={{ color: '#5D866C' }}
          />
          <Input
            placeholder="제목, 내용, 날짜로 검색..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 border-none"
            style={{ 
              backgroundColor: '#F5F5F0',
              color: '#5D866C'
            }}
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2">
          {/* Date Range Filter */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="gap-2"
                style={{ 
                  borderColor: dateRange.from ? '#5D866C' : '#C2A68C',
                  color: '#5D866C',
                  backgroundColor: dateRange.from ? 'rgba(93, 134, 108, 0.1)' : 'transparent'
                }}
              >
                <Calendar className="w-4 h-4" />
                {dateRange.from ? (
                  dateRange.to ? (
                    `${format(dateRange.from, "M/d")} - ${format(dateRange.to, "M/d")}`
                  ) : (
                    format(dateRange.from, "M/d") + " ~"
                  )
                ) : (
                  "날짜 범위"
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarComponent
                mode="range"
                selected={{ from: dateRange.from, to: dateRange.to }}
                onSelect={(range) => setDateRange({ from: range?.from, to: range?.to })}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>

          {/* Favorite Filter */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFavoriteOnly(!showFavoriteOnly)}
            className="gap-2"
            style={{ 
              borderColor: showFavoriteOnly ? '#FFD700' : '#C2A68C',
              color: '#5D866C',
              backgroundColor: showFavoriteOnly ? 'rgba(255, 215, 0, 0.1)' : 'transparent'
            }}
          >
            <Star 
              className="w-4 h-4" 
              fill={showFavoriteOnly ? '#FFD700' : 'none'}
              style={{ color: showFavoriteOnly ? '#FFD700' : '#5D866C' }}
            />
            즐겨찾기만
          </Button>

          {/* Clear Filters */}
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="gap-2"
              style={{ color: '#5D866C' }}
            >
              <X className="w-4 h-4" />
              필터 초기화
            </Button>
          )}
        </div>

        {/* Tag Filters */}
        {allTags.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm" style={{ color: '#5D866C' }}>태그</div>
            <div className="flex flex-wrap gap-2">
              {allTags.map(tag => (
                <Badge
                  key={tag}
                  variant="outline"
                  className="cursor-pointer transition-colors"
                  style={{
                    borderColor: selectedTags.includes(tag) ? '#5D866C' : '#C2A68C',
                    color: '#5D866C',
                    backgroundColor: selectedTags.includes(tag) ? 'rgba(93, 134, 108, 0.2)' : 'transparent'
                  }}
                  onClick={() => toggleTag(tag)}
                >
                  {tag}
                  {selectedTags.includes(tag) && <X className="w-3 h-3 ml-1" />}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Entries Grid */}
      {filteredEntries.length === 0 ? (
        <div 
          className="text-center py-12 rounded-lg"
          style={{ 
            backgroundColor: '#E6D8C3',
            color: '#C2A68C'
          }}
        >
          <Search className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>검색 결과가 없습니다.</p>
          <p className="text-sm mt-2">다른 키워드나 필터를 시도해보세요.</p>
        </div>
      ) : (
        <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4">
          {filteredEntries.map((entry) => (
            <DiaryEntry
              key={entry.id}
              date={new Date(entry.date)}
              title={entry.title}
              content={entry.content}
              tags={entry.tags}
              isFavorite={entry.isFavorite}
              onClick={() => onEntryClick(entry)}
              onDelete={() => onDelete(entry.id)}
              onToggleFavorite={() => onToggleFavorite(entry.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
