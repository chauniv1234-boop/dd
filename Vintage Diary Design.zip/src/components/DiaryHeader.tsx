import { BookOpen } from "lucide-react";

export function DiaryHeader() {
  return (
    <header className="flex items-center gap-3 mb-8">
      <div className="p-3 rounded-lg" style={{ backgroundColor: '#5D866C' }}>
        <BookOpen className="w-6 h-6 text-white" />
      </div>
      <div>
        <h1 className="text-[#5D866C]">나의 빈티지 다이어리</h1>
        <p className="text-sm text-[#C2A68C] mt-1">오늘의 이야기를 기록해보세요</p>
      </div>
    </header>
  );
}
